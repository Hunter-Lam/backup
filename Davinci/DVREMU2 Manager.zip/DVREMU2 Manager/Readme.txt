DVREMU2 - DaVinci Resolve USB Dongle Emulator
---------------------------------------------

Congratulation!
You have successfully installed our "DVREMU2 Manager", but not actual emulator yet.
You need few more steps before running DaVinciResolve.


Quick Start Guide
-----------------
Please follow the instruction after you install DaVinciResolve.

Run DVREMU2 Manager. The "commands" folder opens.
Run "DVREMU2 - Install Emulator.cmd" in the "commands" folder.
Run "DVREMU2 - Renew Emulator License.cmd" in the "commands" folder.

That's it!
When you update DaVinciResolve, you may need to run "DVREMU2 - Install Emulator.cmd" again.


Usage of DVREMU2 Manager
------------------------
Here is more detailed information about the "commands".

Install Emulator :
This will install emulator to the installation folder.
Emulator can be overwritten by updating the software.
Run this command everytime after the software installation.

Renew Emulator License : 
This will generate license and saves to the registry.
The license will be loaded by the emulator.

Test License and Emulator :
This command will check license and emulator installation.
This should be useful for troubleshooting.

Use Shared VCRuntime :
This command will remove VisualStudio Runtime in its DaVinciResolve installation folder.
After removing, DaVinciResolve loads runtime dll files from System32.
This is helpful especially when the third party plugins require the newer runtime than the DaVinciResolve's one.
Of course, you need to install the latest runtime updates from Microsoft!


More Stories
------------
In DVREMU1, it had fixed license in the emulator.
However, the developer often blacklisted our serial number in the license.
This is how this developer kills duplicated-illegal-dongle.

DVREMU2 Manager has the license generator (keygen), that generates unique serial numbers for every users.
This should stop the blacklisting war.

We also improved the user experience in this time.
- No system dll installation.
- No software modification.
- Support upcoming updates.

Have fun with our work :)


Version
-------
v1.0.0
- Initial release


Coded by TEAM R2R 2024
